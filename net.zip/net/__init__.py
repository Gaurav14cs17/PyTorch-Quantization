from net.Esnet_Pa_fpn_yolx import ES_YoloBody
from net.Darknet_pafpn_yolox import YoloBody_Nano
