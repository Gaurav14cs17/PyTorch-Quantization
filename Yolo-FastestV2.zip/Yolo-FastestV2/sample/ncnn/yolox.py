# Tencent is pleased to support the open source community by making ncnn available.
#
# Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
#
# Licensed under the BSD 3-Clause License (the "License"); you may not use this file except
# in compliance with the License. You may obtain a copy of the License at
#
# https://opensource.org/licenses/BSD-3-Clause
#
# Unless required by applicable law or agreed to in writing, software distributed
# under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.

import ncnn
import numpy as np

numAnchor = 3
numCategory = 5


def getCategory(values, index ):
    objScore = values[4 * numAnchor + index]
    score , category = -1 , -1
    for i in range(numCategory):
        clsScore = values[4 * numAnchor + numAnchor + i]
        clsScore *= objScore
        if clsScore > tmp:
            score = clsScore
            category = i
            tmp = clsScore

    return score , category


class Point(object):
    def __init__(self):
        self.x = 0.0
        self.y = 0.0


class Rect(object):
    def __init__(self, x=0, y=0, w=0, h=0):
        self.x = x
        self.y = y
        self.w = w
        self.h = h

    def area(self):
        return self.w * self.h

    def intersection_area(self, b):
        x1 = np.maximum(self.x, b.x)
        y1 = np.maximum(self.y, b.y)
        x2 = np.minimum(self.x + self.w, b.x + b.w)
        y2 = np.minimum(self.y + self.h, b.y + b.h)
        return np.abs(x1 - x2) * np.abs(y1 - y2)


class Detect_Object(object):
    def __init__(self, label=0, prob=0, x=0, y=0, w=0, h=0):
        self.label = label
        self.prob = prob
        self.rect = Rect(x, y, w, h)


class Face_Object(object):
    def __init__(self):
        self.prob = 0.0
        self.rect = Rect()
        self.landmark = []


class KeyPoint(object):
    def __init__(self):
        self.p = Point()
        self.prob = 0.0


class YoloX:
    def __init__(self, target_size=416, num_threads=1, use_gpu=False):
        self.target_size = target_size
        self.num_threads = num_threads
        self.use_gpu = use_gpu

        self.mean_vals = [0.0, 0.0, 0.0]
        self.norm_vals = [1 / 255., 1 / 255., 1 / 255.]

        self.net = ncnn.Net()
        self.net.opt.use_vulkan_compute = self.use_gpu

        # original pretrained model from https://github.com/eric612/MobileNet-YOLO
        # https://github.com/eric612/MobileNet-YOLO/blob/master/models/yolov2/mobilenet_yolo_deploy.prototxt
        # https://github.com/eric612/MobileNet-YOLO/blob/master/models/yolov2/mobilenet_yolo_deploy_iter_80000.caffemodel
        # the ncnn model https://github.com/nihui/ncnn-assets/tree/master/models
        self.net.load_param("./model/yolo-fastestv2-opt.param")
        self.net.load_model("./model/yolo-fastestv2-opt.bin")

        self.class_names = [
            "background",
            "aeroplane",
            "bicycle",
            "bird",
            "boat",
            "bottle",
            "bus",
            "car",
            "cat",
            "chair",
            "cow",
            "diningtable",
            "dog",
            "horse",
            "motorbike",
            "person",
            "pottedplant",
            "sheep",
            "sofa",
            "train",
            "tvmonitor",
        ]

    def __del__(self):
        self.net = None

    def __call__(self, img):
        img_h = img.shape[0]
        img_w = img.shape[1]

        mat_in = ncnn.Mat.from_pixels_resize(
            img,
            ncnn.Mat.PixelType.PIXEL_BGR,
            img.shape[1],
            img.shape[0],
            self.target_size,
            self.target_size,
        )
        mat_in.substract_mean_normalize([], self.norm_vals)
        mat_in.substract_mean_normalize(self.mean_vals, [])

        ex = self.net.create_extractor()
        ex.set_num_threads(self.num_threads)

        ex.input("input.1", mat_in)
        out = []

        ret, mat_out_1 = ex.extract("794")
        ret, mat_out_2 = ex.extract("796")
        out.append(mat_out_1)
        out.append(mat_out_2)

        objects = []
        print(mat_out_1, mat_out_2)

        for i in range(2):
            outH = out[i].c
            outW = out[i].h
            outC = out[i].w
            numAnchor = 3
            stride = img_h / outH
            for h in range(outH):
                values = out[i].channel(h)
                for w in range(outW):
                    for b in range(numAnchor):
                        objScore = values[4 * numAnchor + b]
                        obj = Detect_Object()
                        score, category = getCategory(values , b )
                        if score > 0.1:
                            bcx = ((values[b * 4 + 0] * 2. - 0.5) + w) * stride
                            bcy = ((values[b * 4 + 1] * 2. - 0.5) + h) * stride
                            print(bcx , bcy)
                            # bw = pow((values[b * 4 + 2] * 2.), 2) * anchor[(i * numAnchor * 2) + b * 2 + 0]
                            # bh = pow((values[b * 4 + 3] * 2.), 2) * anchor[(i * numAnchor * 2) + b * 2 + 1]
                            # obj.label = values[0]
                            # obj.prob = values[1]
                            # obj.rect.x = values[2] * img_w
                            # obj.rect.y = values[3] * img_h
                            # obj.rect.w = values[4] * img_w - obj.rect.x
                            # obj.rect.h = values[5] * img_h - obj.rect.y
                            #
                            # objects.append(obj)

        #
        #
        #         TargetBox tmpBox;
        #         int category = -1;
        #         float score = -1;
        #
        #         getCategory(values, b, category, score);
        #
        #         if (score > thresh) {
        #         float bcx, bcy, bw, bh;
        #
        #         bcx = ((values[b * 4 + 0] * 2. - 0.5) + w) * stride;
        #         bcy = ((values[b * 4 + 1] * 2. - 0.5) + h) * stride;
        #         bw = pow((values[b * 4 + 2] * 2.), 2) * anchor[(i * numAnchor * 2) + b * 2 + 0];
        #         bh = pow((values[b * 4 + 3] * 2.), 2) * anchor[(i * numAnchor * 2) + b * 2 + 1];
        #
        #         tmpBox.x1 = (bcx - 0.5 * bw) * scaleW;
        #         tmpBox.y1 = (bcy - 0.5 * bh) * scaleH;
        #         tmpBox.x2 = (bcx + 0.5 * bw) * scaleW;
        #         tmpBox.y2 = (bcy + 0.5 * bh) * scaleH;
        #         tmpBox.score = score;
        #         tmpBox.cate = category;
        #
        #         dstBoxes.push_back(tmpBox);
        #         }
        #         }
        #         values += outC;
        #         }
        #         }
        #         }
        #         return 0;
        #
        # }

        # method 1, use ncnn.Mat.row to get the result, no memory copy
        for i in range(mat_out_1.h):
            values = mat_out_1.row(i)

            obj = Detect_Object()
            obj.label = values[0]
            obj.prob = values[1]
            obj.rect.x = values[2] * img_w
            obj.rect.y = values[3] * img_h
            obj.rect.w = values[4] * img_w - obj.rect.x
            obj.rect.h = values[5] * img_h - obj.rect.y

            objects.append(obj)

        """
        #method 2, use ncnn.Mat->numpy.array to get the result, no memory copy too
        out = np.array(mat_out)
        for i in range(len(out)):
            values = out[i]
            obj = Detect_Object()
            obj.label = values[0]
            obj.prob = values[1]
            obj.rect.x = values[2] * img_w
            obj.rect.y = values[3] * img_h
            obj.rect.w = values[4] * img_w - obj.rect.x
            obj.rect.h = values[5] * img_h - obj.rect.y
            objects.append(obj)
        """

        return objects


import cv2

if __name__ == '__main__':
    obj = YoloX()
    image = cv2.imread("test.jpg")
    output = obj(image)
    print(output)
