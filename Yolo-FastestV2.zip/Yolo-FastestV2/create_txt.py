import os, tqdm

val_dir_path = "/media/gaurav/ssd/Face_data/WIDER_val/images"
train_dir_path = "/media/gaurav/ssd/Face_data/WIDER_train/images"


def create_txt(file_path, name='train.txt'):
    with open(name, "w") as f:
        for image_name in os.listdir(file_path):
            if image_name.endswith('.jpg'):
                full_image_path = os.path.join(file_path, image_name)
                print(full_image_path)
                f.write(f"{full_image_path}\n")
        print("YOLO txt finished!")



create_txt(val_dir_path ,name = 'val.txt')
create_txt(train_dir_path , name='train.txt')